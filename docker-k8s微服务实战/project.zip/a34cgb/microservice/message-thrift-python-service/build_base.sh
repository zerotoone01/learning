#!/usr/bin/env bash

docker build -t python-base:latest -f Dockerfile.base .