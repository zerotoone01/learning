package com.imooc.apigateway.exception;

/**
 * Created by 廖师兄
 * 2018-03-11 23:56
 */
public class RateLimitException extends RuntimeException {
}
